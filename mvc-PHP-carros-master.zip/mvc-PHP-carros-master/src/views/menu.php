<hr>
    <a href="index.php" class="btn btn-default">Início</a>
    <a href="cadastroCarro.php" class= "btn btn-success">Cadastrar Carro</a>
    <a href="cadastroMotor.php" class= "btn btn-success">Cadastrar Motor</a>
    <a href="listarMotores.php" class= "btn btn-success">Listar Motores</a>
</hr>