<?php

class ControllerUpdateMotor{
    public function __construct(){

    }
}