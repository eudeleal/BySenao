<?php

class ControllerDeleteCarro{
    public function __construct(){

    }
}