<?php

class ControllerDeleteMotor{
    public function __construct(){

    }
}