<?php

date_default_timezone_set('America/Sao_Paulo');

define('DB_SERVIDOR','localhost');
define('DB_USUARIO','levi');
define('DB_SENHA', '123');
define('DB_BANCO','concessionaria');