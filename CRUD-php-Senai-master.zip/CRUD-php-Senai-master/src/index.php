<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>SENAI</title>
    </head>
    <body>
        <h1>Formulário SENAI</h1>
        <form action= form_cad_cliente.php method=get>
            <input type=submit value ='cadastro de clientes'/>
        </form>
    </body>
</html>