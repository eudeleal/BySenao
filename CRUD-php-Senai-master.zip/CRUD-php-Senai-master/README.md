# CRUD-php-Senai
CRUD com php para aulas do SENAI, DS1

**Objetivo**

Fazer um CRUD com Php utilizando os conceitos de Orientação a Objetos.

**Justificativa**

Esse projeto faz parte de uma atividade avaliativa da disciplina de Desenvolvimento de software 1, do curso Técnico de Desenvolvimento de Software do SENAI.

**Autores**
Foto | Nome | GitHub | Likedin | E-mail
---- | ---- | ------ | ------- | ------
<img src="Doc/levi.jpeg" width="100px"> | Rafael Levi Batista Costa | [Rafaellevissa](https://github.com/rafaellevissa) | [Linkedin](https://www.linkedin.com/in/rafael-costa-8791b258/) | rafaellevissa@gmail.com

**Tecnologias**

Linguagem:

- php

Banco de dados

- Mysql

